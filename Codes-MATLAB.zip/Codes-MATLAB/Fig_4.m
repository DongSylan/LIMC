%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Load the data and toolbox
  % Load the data
    Name_Image        = 'Lenna.jpg';
    Image_Gray        = imread(Name_Image);
    Data_Original     = double(Image_Gray);
  % Load the toolbox
    PATH_Functions_MC = genpath('Functions_MC');
    addpath(PATH_Functions_MC);
    
    
%% Public parameter setting 
    M = Data_Original;
    [m, n] = size(M);
  % Sampling Ratio on original image
    SR_Original = 40;
  % The number of Indepent samples
    Num_Inds    = 10;
  % epsilon
    epsilon     = 1e-4;
  % MaxIter
    MaxIter     = 500;
    
    
%% Parameter setting for algorithms
  % lambda
    lambda_EXP    = -6:0;     % Best at 1e-4
    lambda_Set    = 10.^lambda_EXP;
  % LIMC
    Rm                = diag(ones(m-1, 1), 1) + diag(ones(m-1, 1), -1)  - 2*eye(m);
    Rm(1, 1)          = -1;   
    Rm(m, m)          = -1; 
    RmRmt             = Rm*Rm';
    Rn                = diag(ones(n-1, 1), 1) + diag(ones(n-1, 1), -1)  - 2*eye(n);
    Rn(1, 1)          = -1;   
    Rn(n, n)          = -1; 
    RnRnt             = Rn*Rn';
    Para_LIMC.rho     = 1e-2;
    Para_LIMC.MaxIter = MaxIter;
    Para_LIMC.epsilon = epsilon;

    
%% PSNR + SSIM + CPUTime 
    PSNR_Set = zeros(length(lambda_Set), 1);
    SSIM_Set = zeros(length(lambda_Set), 1);
    CPUTime_Set = zeros(length(lambda_Set), 1);
    

%% Main 
    for i = 1:Num_Inds
        i
        
        Index = randi(100, m, n);
        Omega = Index < SR_Original;
        M_Omega = M.*Omega;
        Unknown = 1 - Omega;
    
        for j = 1:length(lambda_Set)
            lambda_LIMC = lambda_Set(j);
            
          % Solve via LIMC algorithm
            tic
            Data_Recovered = LIMC_Ecnomic(m, n, Omega, M_Omega, lambda_LIMC, RmRmt, RnRnt, Para_LIMC);
            t_CPUTime = toc;
            % CPUTime
            CPUTime_Set(j) = CPUTime_Set(j) + t_CPUTime/Num_Inds;
            % Output of LIMC
            Data_Recovered = max(Data_Recovered, 0);
            Data_Recovered = min(Data_Recovered, 255);
            Data_Recovered = M_Omega + Data_Recovered.*Unknown;
            % PSNR
            PSNR_Set(j) = PSNR_Set(j) + PSNR(Data_Original, Data_Recovered, Unknown)/Num_Inds;
            % SSIM
            SSIM_Set(j) = SSIM_Set(j) + ssim_index(Data_Original, Data_Recovered)/Num_Inds;
          
        end
    
    end
    
    
%% Save results
    save Fig_4
    
    
%% File address
    File_Address = 'Fig_4\';
    mkdir('Fig_4') 
    
    
%% Results
  % PSNR
    figure
    h_PSNR = plot(lambda_EXP, PSNR_Set);
    set(h_PSNR, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 4);
    xlim([lambda_EXP(1), lambda_EXP(end)])
    xlabel('log_{10}\lambda', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('PSNR(dB)', 'FontWeight', 'bold', 'FontSize', 20)
    grid on
    set(gca, 'FontSize', 20, 'FontWeight','bold', 'XTick', lambda_EXP, 'position', [0.15, 0.2, 0.7, 0.7]) % 
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'lambda-PSNR.jpg'])
    saveas(gcf, [File_Address 'lambda-PSNR.fig'])
    

  % SSIM
    figure
    h_SSIM = plot(lambda_EXP, SSIM_Set);
    set(h_SSIM, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 4);
    xlim([lambda_EXP(1), lambda_EXP(end)])
    xlabel('log_{10}\lambda', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('SSIM', 'FontWeight', 'bold', 'FontSize', 20)
    grid on
    set(gca, 'FontSize', 20, 'FontWeight','bold', 'XTick', lambda_EXP, 'position', [0.15, 0.2, 0.7, 0.7]) % 
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'lambda-SSIM.jpg'])
    saveas(gcf, [File_Address 'lambda-SSIM.fig'])

    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions_MC);
   
   
    