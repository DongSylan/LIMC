%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Load the data and toolbox
  % Load the original data
    Name_Image        = 'Lenna.jpg';
    Image_Gray        = imread(Name_Image);
    Data_Original     = double(Image_Gray);
  % Load the text image
    Name_Cover = 'Text_Image.jpg';
    Data_Cover = double(imread(Name_Cover));  % 0 menas black 255 means white
  % Construct the image with test
    Omega = Data_Cover > 200;
    Unknown = ~Omega;
    M_Omega = Data_Original.*Omega;
  % Load the toolbox of functions for MC
    PATH_Functions_MC = genpath('Functions_MC');
    addpath(PATH_Functions_MC);
    
    
%% Parameters for windows
  % First window
    Position_Window_1 = [190 215 40 40];  % [XMIN YMIN WIDTH HEIGHT]
    Imresize_Ratio_1 = 1.8;
    Location_Image_Resized_1 = 'LeftBottom'; % 'LeftTop', 'RightTop', 'LeftBottom', 'RightBottom'.
    Color_Window_1 = 'r';
    LineStyle_Window_1 = '-';
  % Second window
    Position_Window_2 = [195 15 50 50];  % [XMIN YMIN WIDTH HEIGHT]
    Imresize_Ratio_2 = 1.8;
    Location_Image_Resized_2 = 'LeftTop'; % 'LeftTop', 'RightTop', 'LeftBottom', 'RightBottom'.
    Color_Window_2 = 'g';
    LineStyle_Window_2 = '-';
    
    
%% Public parameter setting 
    [m, n]  = size(Data_Original);
  % epsilon
    epsilon = 1e-4;
  % MaxIter
    MaxIter = 500;  
    
   
%% Parameter setting for algorithms
  % IRLS
    lambda_IRLS           = 1e-4;
    q_IRLS                = 0.5; 
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.rank_adjust = 1;     
    Para_IRLS.rank        = 20;
    Para_IRLS.min_rank    = 5;    
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.maxit       = MaxIter;
    Para_IRLS.tol         = 1e-5;
    
  % PSSV
    Para_PSSV.rho     = 1e-3;
    % Stopping rules 
    Para_PSSV.MaxIter = MaxIter;
    Para_PSSV.epsilon = epsilon;
    
  % LTVNN
    gamma_LTVNN               = 0.5;
    Para_LTVNN.lambda         = 1e0;
    % Parameters for Column TV 
    Para_LTVNN.MaxIter_Column = MaxIter;
    Para_LTVNN.epsilon_Column = epsilon;
    In                       = eye(n);
    e_n_1                    = [zeros(n-2, 1); 1];
    phi1                     = [zeros(1, n); [eye(n-1), e_n_1]];
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    Para_LTVNN.Matrix_Column  = In - phi1 - phi1' + phi1*phi1'; 
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    % Parameters for Row TV 
    Para_LTVNN.MaxIter_Row    = MaxIter;
    Para_LTVNN.epsilon_Row    = epsilon;
    Im                       = eye(m);
    e_m_1                    = [zeros(m-2, 1); 1];
    phi2                     = [zeros(m, 1), [eye(m-1); e_m_1']];
    Para_LTVNN.Matrix_Row     = Im - phi2 - phi2' + phi2'*phi2;
    
  % SPC
    PATH_Functions_SPC = genpath('Function_SPC');
    addpath(PATH_Functions_SPC);
    K       = 10;          % Number of components which are updated in one iteration. (typically 10)
    SNR     = 30;          % error bound
    nu      = 0.01;        % threshold for R <-- R + 1.
    maxiter = MaxIter;     % maximum number of iteration
    tol     = 1e-5;        % tolerance
    out_im  = 1;           % you can monitor the process of 'image' completion if out == 1. 'saved' directory is necessary to save the individual rank images.
    %%%%%% ---- In image recovery problems, such as denoising and restoration, it is generally considered that the TV constraint is better than QV. ---- %%%%%%
    %--SPC-TV
    TV     = 'tv';        % 'tv' or 'qv' ;
    rho_TV = [0.01 0.01]; % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %--SPC-QV
    QV     = 'qv';        % 'tv' or 'qv' ;
    rho_QV = [0.5 0.5];   % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %%%%%% ----------- On the other hand, our result implies that the QV constraint performs better than TV for the image completion problem. ----------- %%%%%%
    
  % LIMC
    lambda_LIMC       = 1e-4;
    Rm                = diag(ones(m-1, 1), 1) + diag(ones(m-1, 1), -1)  - 2*eye(m);
    Rm(1, 1)          = -1;   
    Rm(m, m)          = -1; 
    RmRmt             = Rm*Rm';
    Rn                = diag(ones(n-1, 1), 1) + diag(ones(n-1, 1), -1)  - 2*eye(n);
    Rn(1, 1)          = -1;   
    Rn(n, n)          = -1; 
    RnRnt             = Rn*Rn';
    Para_LIMC.rho     = 1e-2;
    Para_LIMC.MaxIter = MaxIter;
    Para_LIMC.epsilon = epsilon;
    
    
%% Parameters for variables
    PSNR_All        = zeros(6, 1);
    SSIM_All        = zeros(6, 1);
    CPUTime_All     = zeros(6, 1);
    
    
%% Main
    %%%-----------------------------Different Algorithms-----------------------------%%%
  % IRLS
    tic
    Data_Recovered_IRLS = tIRucLq_m(m, n, Omega, M_Omega, lambda_IRLS, q_IRLS, Para_IRLS);
    % Compute the CPUTime
    CPUTime_IRLS = toc;
    CPUTime_All(1) = CPUTime_IRLS;
    % Output of IRLS
    Data_Recovered_IRLS = max(Data_Recovered_IRLS, 0);
    Data_Recovered_IRLS = min(Data_Recovered_IRLS, 255);
    Data_Recovered_IRLS = M_Omega + Data_Recovered_IRLS.*Unknown;
    % PSNR
    PSNR_All(1)         = PSNR(Data_Original, Data_Recovered_IRLS, Unknown);
    % SSIM
    SSIM_All(1)         = ssim_index(Data_Original, Data_Recovered_IRLS);

  % PSSV
    PSNR_SSIM_Best = 0;
    for rank_estimate = 5:20
        tic
        Data_Recovered_PSSV_rank = PSSV(m, n, Omega, M_Omega, rank_estimate, Para_PSSV);
        % Compute the CPUTime
        CPUTime_PSSV = toc;
        CPUTime_All(2) = CPUTime_All(2) + CPUTime_PSSV;
        % Output of PSSV
        Data_Recovered_PSSV_rank = max(Data_Recovered_PSSV_rank, 0);
        Data_Recovered_PSSV_rank = min(Data_Recovered_PSSV_rank, 255);
        Data_Recovered_PSSV_rank = M_Omega + Data_Recovered_PSSV_rank.*Unknown;
        % PSNR-rank
        PSNR_rank           = PSNR(Data_Original, Data_Recovered_PSSV_rank, Unknown);
        % SSIM-rank
        SSIM_rank           = ssim_index(Data_Original, Data_Recovered_PSSV_rank);
        % PSNR-SSIM-rank
        PSNR_SSIM_rank = PSNR_rank + 30*SSIM_rank;
        if PSNR_SSIM_rank >= PSNR_SSIM_Best
            PSNR_SSIM_Best = PSNR_SSIM_rank;
            PSNR_Best = PSNR_rank;
            SSIM_Best = SSIM_rank;
            Data_Recovered_PSSV = Data_Recovered_PSSV_rank;
        end
    end
    % PSNR
    PSNR_All(2)    = PSNR_Best;
    % SSIM
    SSIM_All(2)    = SSIM_Best;

  % LTVNN
    tic
    Data_Recovered_LTVNN = LTVNN(m, n, Omega, M_Omega, gamma_LTVNN, Para_LTVNN);
    % Compute the CPUTime
    CPUTime_LTVNN = toc;
    CPUTime_All(3) = CPUTime_LTVNN;
    % Output of LTVNN
    Data_Recovered_LTVNN  = max(Data_Recovered_LTVNN, 0);
    Data_Recovered_LTVNN  = min(Data_Recovered_LTVNN, 255);
    Data_Recovered_LTVNN = M_Omega + Data_Recovered_LTVNN.*Unknown;
    % PSNR
    PSNR_All(3)          = PSNR(Data_Original, Data_Recovered_LTVNN, Unknown);
    % SSIM
    SSIM_All(3)          = ssim_index(Data_Original, Data_Recovered_LTVNN);

  % SPC-TV
    tic
    Data_Recovered_SPC_TV = SPC(M_Omega, Omega, TV, rho_TV, K, SNR, nu, maxiter, tol, out_im);
    % Compute the CPUTime
    CPUTime_SPC_TV = toc;
    CPUTime_All(4) = CPUTime_SPC_TV;
    % Output of SPC-TV
    Data_Recovered_SPC_TV = max(Data_Recovered_SPC_TV, 0);
    Data_Recovered_SPC_TV = min(Data_Recovered_SPC_TV, 255);
    Data_Recovered_SPC_TV = M_Omega + Data_Recovered_SPC_TV.*Unknown;
    % PSNR
    PSNR_All(4)           = PSNR(Data_Original, Data_Recovered_SPC_TV, Unknown);
    % SSIM
    SSIM_All(4)           = ssim_index(Data_Original, Data_Recovered_SPC_TV);

  % SPC-QV
    tic
    Data_Recovered_SPC_QV = SPC(M_Omega, Omega, QV, rho_QV, K, SNR, nu, maxiter, tol, out_im);
    % Compute the CPUTime
    CPUTime_SPC_QV = toc;
    CPUTime_All(5) = CPUTime_SPC_QV;
    % Output of SPC-QV
    Data_Recovered_SPC_QV = max(Data_Recovered_SPC_QV, 0);
    Data_Recovered_SPC_QV = min(Data_Recovered_SPC_QV, 255);
    Data_Recovered_SPC_QV = M_Omega + Data_Recovered_SPC_QV.*Unknown;
    % PSNR
    PSNR_All(5)           = PSNR(Data_Original, Data_Recovered_SPC_QV, Unknown);
    % SSIM
    SSIM_All(5)           = ssim_index(Data_Original, Data_Recovered_SPC_QV);

  % LIMC
    tic
    Data_Recovered_LIMC = LIMC_Ecnomic(m, n, Omega, M_Omega, lambda_LIMC, RmRmt, RnRnt, Para_LIMC);
    % Compute the CPUTime
    CPUTime_LIMC = toc;
    CPUTime_All(6) = CPUTime_LIMC;
    % Output of LIMC
    Data_Recovered_LIMC = max(Data_Recovered_LIMC, 0);
    Data_Recovered_LIMC = min(Data_Recovered_LIMC, 255);
    Data_Recovered_LIMC = M_Omega + Data_Recovered_LIMC.*Unknown;
    % PSNR
    PSNR_All(6)         = PSNR(Data_Original, Data_Recovered_LIMC, Unknown);
    % SSIM
    SSIM_All(6)         = ssim_index(Data_Original, Data_Recovered_LIMC);
    %%%-----------------------------Different Algorithms-----------------------------%%%
  
    
%% Save results
    save Fig_7
    
    
%% File address
    File_Address = 'Fig_7\';
    mkdir('Fig_7')  
    
    
%% Results
    figure
    % Original image
    subplot(2, 4, 1)
    imshow(Data_Original/255)
    title('Original image')
    % Masked image
    subplot(2, 4, 2)
    imshow(M_Omega/255)
    title('Masked image')
    % IRLS
    subplot(2, 4, 3)
    imshow(Data_Recovered_IRLS/255)
    title(['IRLS(' num2str(PSNR_All(1))  ' | ' num2str(SSIM_All(1)) ')'])
    % PSSV
    subplot(2, 4, 4)
    imshow(Data_Recovered_PSSV/255)
    title(['PSSV(' num2str(PSNR_All(2))  ' | ' num2str(SSIM_All(2)) ')'])
    % LTVNN
    subplot(2, 4, 5)
    imshow(Data_Recovered_LTVNN/255)
    title(['LTVNN(' num2str(PSNR_All(3))  ' | ' num2str(SSIM_All(3)) ')'])
    % SPC-TV
    subplot(2, 4, 6)
    imshow(Data_Recovered_SPC_TV/255)
    title(['SPC-TV(' num2str(PSNR_All(4))  ' | ' num2str(SSIM_All(4)) ')'])
    % SPC-QV 
    subplot(2, 4, 7)
    imshow(Data_Recovered_SPC_QV/255)
    title(['SPC-QV(' num2str(PSNR_All(5))  ' | ' num2str(SSIM_All(5)) ')'])
    % LIMC
    subplot(2, 4, 8)
    imshow(Data_Recovered_LIMC/255)
    title(['Ours(' num2str(PSNR_All(6))  ' | ' num2str(SSIM_All(6)) ')'])
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'All.jpg'])
    saveas(gcf, [File_Address 'All.fig'])
    
  % Original image
    figure
    h1 = Image_Synthesizer(uint8(Data_Original), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(Data_Original), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title('Original image')
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Original-Image.jpg'])
    saveas(gcf, [File_Address 'Original-Image.fig'])
  % Masked image
    figure
    h1 = Image_Synthesizer(uint8(M_Omega), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(M_Omega), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title('Masked image')
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Masked-Image.jpg'])
    saveas(gcf, [File_Address 'Masked-Image.fig'])
  % IRLS
    figure
    h1 = Image_Synthesizer(uint8(Data_Recovered_IRLS), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(Data_Recovered_IRLS), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title(['IRLS(' num2str(PSNR_All(1))  ' | ' num2str(SSIM_All(1)) ')'])
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'IRLS.jpg'])
    saveas(gcf, [File_Address 'IRLS.fig'])
  % PSSV
    figure
    h1 = Image_Synthesizer(uint8(Data_Recovered_PSSV), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(Data_Recovered_PSSV), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title(['PSSV(' num2str(PSNR_All(2))  ' | ' num2str(SSIM_All(2)) ')'])
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'PSSV.jpg'])
    saveas(gcf, [File_Address 'PSSV.fig'])
  % LTVNN
    figure
    h1 = Image_Synthesizer(uint8(Data_Recovered_LTVNN), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(Data_Recovered_LTVNN), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title(['LTVNN(' num2str(PSNR_All(3))  ' | ' num2str(SSIM_All(3)) ')'])
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'LTVNN.jpg'])
    saveas(gcf, [File_Address 'LTVNN.fig'])
  % SPC-TV
    figure
    h1 = Image_Synthesizer(uint8(Data_Recovered_SPC_TV), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(Data_Recovered_SPC_TV), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title(['SPC-TV(' num2str(PSNR_All(4))  ' | ' num2str(SSIM_All(4)) ')'])
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'SPC-TV.jpg'])
    saveas(gcf, [File_Address 'SPC-TV.fig'])
  % SPC-QV
    figure
    h1 = Image_Synthesizer(uint8(Data_Recovered_SPC_QV), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(Data_Recovered_SPC_QV), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title(['SPC-QV(' num2str(PSNR_All(5))  ' | ' num2str(SSIM_All(5)) ')'])
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'SPC-QV.jpg'])
    saveas(gcf, [File_Address 'SPC-QV.fig'])
  % LIMC
    figure
    h1 = Image_Synthesizer(uint8(Data_Recovered_LIMC), Position_Window_1, Imresize_Ratio_1, Location_Image_Resized_1, Color_Window_1, LineStyle_Window_1);
    hold on
    h2 = Image_Synthesizer_Addition(uint8(Data_Recovered_LIMC), Position_Window_2, Imresize_Ratio_2, Location_Image_Resized_2, Color_Window_2, LineStyle_Window_2);
    title(['Ours(' num2str(PSNR_All(6))  ' | ' num2str(SSIM_All(6)) ')'])
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'LIMC.jpg'])
    saveas(gcf, [File_Address 'LIMC.fig'])
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions_MC);
   rmpath(PATH_Functions_SPC);
   
   
    