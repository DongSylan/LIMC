%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Load the data and toolbox
  % Load the data
    Name_Image        = 'Lenna.jpg';
    Image_Gray        = imread(Name_Image);
    Data_Original     = double(Image_Gray);
  % Load the toolbox
    PATH_Functions_MC = genpath('Functions_MC');
    addpath(PATH_Functions_MC);
    
    
%% Parameters for window
    Position_Window = [110 120 70 70];  % [XMIN YMIN WIDTH HEIGHT]
    Imresize_Ratio = 1.6;
    Location_Image_Resized = 'LeftTop'; % 'LeftTop', 'RightTop', 'LeftBottom', 'RightBottom'.
    Color_Window = 'g';
    LineStyle_Window = '-';
    
    
%% Public parameter setting 
    M                 = Data_Original;
    [m, n]            = size(M);
  % epsilon
    epsilon           = 1e-4;
  % MaxIter
    MaxIter           = 500;
    SR_Original_Set   = [30 35 40 45 50]; 
    SR_Original_Index = 3;
    

%% Parameter setting for algorithms
  % IRLS
    lambda_IRLS           = 1e-4;
    q_IRLS                = 0.5; 
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.rank_adjust = 1;     
    Para_IRLS.rank        = 20;
    Para_IRLS.min_rank    = 5;    
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.maxit       = MaxIter;
    Para_IRLS.tol         = 1e-5;
    
  % PSSV
    Para_PSSV.rho     = 1e-3;
    % Stopping rules 
    Para_PSSV.MaxIter = MaxIter;
    Para_PSSV.epsilon = epsilon;
    
  % LTVNN
    gamma_LTVNN               = 0.5;
    Para_LTVNN.lambda         = 1e0;
    % Parameters for Column TV 
    Para_LTVNN.MaxIter_Column = MaxIter;
    Para_LTVNN.epsilon_Column = epsilon;
    In                       = eye(n);
    e_n_1                    = [zeros(n-2, 1); 1];
    phi1                     = [zeros(1, n); [eye(n-1), e_n_1]];
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    Para_LTVNN.Matrix_Column  = In - phi1 - phi1' + phi1*phi1'; 
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    % Parameters for Row TV 
    Para_LTVNN.MaxIter_Row    = MaxIter;
    Para_LTVNN.epsilon_Row    = epsilon;
    Im                       = eye(m);
    e_m_1                    = [zeros(m-2, 1); 1];
    phi2                     = [zeros(m, 1), [eye(m-1); e_m_1']];
    Para_LTVNN.Matrix_Row     = Im - phi2 - phi2' + phi2'*phi2;
    
  % SPC
    PATH_Functions_SPC = genpath('Function_SPC');
    addpath(PATH_Functions_SPC);
    K       = 10;          % Number of components which are updated in one iteration. (typically 10)
    SNR     = 30;          % error bound
    nu      = 0.01;        % threshold for R <-- R + 1.
    maxiter = MaxIter;     % maximum number of iteration
    tol     = 1e-5;        % tolerance
    out_im  = 1;           % you can monitor the process of 'image' completion if out == 1. 'saved' directory is necessary to save the individual rank images.
    %%%%%% ---- In image recovery problems, such as denoising and restoration, it is generally considered that the TV constraint is better than QV. ---- %%%%%%
    %--SPC-TV
    TV     = 'tv';        % 'tv' or 'qv' ;
    rho_TV = [0.01 0.01]; % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %--SPC-QV
    QV     = 'qv';        % 'tv' or 'qv' ;
    rho_QV = [0.5 0.5];   % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %%%%%% ----------- On the other hand, our result implies that the QV constraint performs better than TV for the image completion problem. ----------- %%%%%%
    
  % LIMC
    lambda_LIMC       = 1e-4;
    Rm                = diag(ones(m-1, 1), 1) + diag(ones(m-1, 1), -1)  - 2*eye(m);
    Rm(1, 1)          = -1;   
    Rm(m, m)          = -1; 
    RmRmt             = Rm*Rm';
    Rn                = diag(ones(n-1, 1), 1) + diag(ones(n-1, 1), -1)  - 2*eye(n);
    Rn(1, 1)          = -1;   
    Rn(n, n)          = -1; 
    RnRnt             = Rn*Rn';
    Para_LIMC.rho     = 1e-2;
    Para_LIMC.MaxIter = MaxIter;
    Para_LIMC.epsilon = epsilon;
    
    
%% Parameters for variables
    Num_SR_Original = length(SR_Original_Set);
    PSNR_All        = zeros(6, Num_SR_Original);
    SSIM_All        = zeros(6, Num_SR_Original);
    CPUTime_All     = zeros(6, Num_SR_Original);
    
    
%% Main 
    for i = 1:Num_SR_Original
        i
        
      % Sampling Ratio on original image
        SR_Original = SR_Original_Set(i);
        Index       = randi(100, m, n);
        Omega       = Index < SR_Original;
        M_Omega     = M.*Omega;
        Unknown     = 1 - Omega;
        
        %%%-----------------------------Different Algorithms-----------------------------%%%
        % IRLS
        tic
        Data_Recovered_IRLS = tIRucLq_m(m, n, Omega, M_Omega, lambda_IRLS, q_IRLS, Para_IRLS);
        % Compute the CPUTime
        CPUTime_IRLS = toc;
        CPUTime_All(1, i) = CPUTime_IRLS;
        % Output of IRLS
        Data_Recovered_IRLS = max(Data_Recovered_IRLS, 0);
        Data_Recovered_IRLS = min(Data_Recovered_IRLS, 255);
        Data_Recovered_IRLS = M_Omega + Data_Recovered_IRLS.*Unknown;
        % PSNR
        PSNR_All(1, i)      = PSNR(Data_Original, Data_Recovered_IRLS, Unknown);
        % SSIM
        SSIM_All(1, i)      = ssim_index(Data_Original, Data_Recovered_IRLS);
        % Image show
        if i == SR_Original_Index
            Image_IRLS = Data_Recovered_IRLS;
        end
        
        % PSSV
        PSNR_SSIM_Best = 0;
        for rank_estimate = 5:20
            tic
            Data_Recovered_PSSV_rank = PSSV(m, n, Omega, M_Omega, rank_estimate, Para_PSSV);
            % Compute the CPUTime
            CPUTime_PSSV = toc;
            CPUTime_All(2, i) = CPUTime_All(2, i) + CPUTime_PSSV;
            % Output of PSSV
            Data_Recovered_PSSV_rank = max(Data_Recovered_PSSV_rank, 0);
            Data_Recovered_PSSV_rank = min(Data_Recovered_PSSV_rank, 255);
            Data_Recovered_PSSV_rank = M_Omega + Data_Recovered_PSSV_rank.*Unknown;
            % PSNR-rank
            PSNR_rank           = PSNR(Data_Original, Data_Recovered_PSSV_rank, Unknown);
            % SSIM-rank
            SSIM_rank           = ssim_index(Data_Original, Data_Recovered_PSSV_rank);
            % PSNR-SSIM-rank
            PSNR_SSIM_rank = PSNR_rank + 30*SSIM_rank;
            if PSNR_SSIM_rank >= PSNR_SSIM_Best
                PSNR_SSIM_Best = PSNR_SSIM_rank;
                PSNR_PSSV = PSNR_rank;
                SSIM_PSSV = SSIM_rank;
                Data_Recovered_PSSV = Data_Recovered_PSSV_rank;
            end
        end
        % PSNR
        PSNR_All(2, i)    = PSNR_PSSV;
        % SSIM
        SSIM_All(2, i)    = SSIM_PSSV;
        % Image show
        if i == SR_Original_Index
            Image_PSSV = Data_Recovered_PSSV;
        end
        
        % LTVNN
        tic
        Data_Recovered_LTVNN = LTVNN(m, n, Omega, M_Omega, gamma_LTVNN, Para_LTVNN);
        % Compute the CPUTime
        CPUTime_LTVNN = toc;
        CPUTime_All(3, i) = CPUTime_LTVNN;
        % Output of LTVNN
        Data_Recovered_LTVNN  = max(Data_Recovered_LTVNN, 0);
        Data_Recovered_LTVNN  = min(Data_Recovered_LTVNN, 255);
        Data_Recovered_LTVNN = M_Omega + Data_Recovered_LTVNN.*Unknown;
        % PSNR
        PSNR_All(3, i)       = PSNR(Data_Original, Data_Recovered_LTVNN, Unknown);
        % SSIM
        SSIM_All(3, i)      = ssim_index(Data_Original, Data_Recovered_LTVNN);
        % Image show
        if i == SR_Original_Index
            Image_LTVNN = Data_Recovered_LTVNN;
        end
        
        % SPC-TV
        tic
        Data_Recovered_SPC_TV = SPC(M_Omega, Omega, TV, rho_TV, K, SNR, nu, maxiter, tol, out_im);
        % Compute the CPUTime
        CPUTime_SPC_TV = toc;
        CPUTime_All(4, i) = CPUTime_SPC_TV;
        % Output of SPC-TV
        Data_Recovered_SPC_TV = max(Data_Recovered_SPC_TV, 0);
        Data_Recovered_SPC_TV = min(Data_Recovered_SPC_TV, 255);
        Data_Recovered_SPC_TV = M_Omega + Data_Recovered_SPC_TV.*Unknown;
        % PSNR
        PSNR_All(4, i)      = PSNR(Data_Original, Data_Recovered_SPC_TV, Unknown);
        % SSIM
        SSIM_All(4, i)      = ssim_index(Data_Original, Data_Recovered_SPC_TV);
        % Image show
        if i == SR_Original_Index
            Image_SPC_TV = Data_Recovered_SPC_TV;
        end
        
       % SPC-QV
        tic
        Data_Recovered_SPC_QV = SPC(M_Omega, Omega, QV, rho_QV, K, SNR, nu, maxiter, tol, out_im);
        % Compute the CPUTime
        CPUTime_SPC_QV = toc;
        CPUTime_All(5, i) = CPUTime_SPC_QV;
        % Output of SPC-QV
        Data_Recovered_SPC_QV = max(Data_Recovered_SPC_QV, 0);
        Data_Recovered_SPC_QV = min(Data_Recovered_SPC_QV, 255);
        Data_Recovered_SPC_QV = M_Omega + Data_Recovered_SPC_QV.*Unknown;
        % PSNR
        PSNR_All(5, i)      = PSNR(Data_Original, Data_Recovered_SPC_QV, Unknown);
        % SSIM
        SSIM_All(5, i)      = ssim_index(Data_Original, Data_Recovered_SPC_QV);
        % Image show
        if i == SR_Original_Index
            Image_SPC_QV = Data_Recovered_SPC_QV;
        end
        
        % LIMC
        tic
        Data_Recovered_LIMC = LIMC_Ecnomic(m, n, Omega, M_Omega, lambda_LIMC, RmRmt, RnRnt, Para_LIMC);
        % Compute the CPUTime
        CPUTime_LIMC = toc;
        CPUTime_All(6, i) = CPUTime_LIMC;
        % Output of LIMC
        Data_Recovered_LIMC = max(Data_Recovered_LIMC, 0);
        Data_Recovered_LIMC = min(Data_Recovered_LIMC, 255);
        Data_Recovered_LIMC = M_Omega + Data_Recovered_LIMC.*Unknown;
        % PSNR
        PSNR_All(6, i)      = PSNR(Data_Original, Data_Recovered_LIMC, Unknown);
        % SSIM
        SSIM_All(6, i)      = ssim_index(Data_Original, Data_Recovered_LIMC);
        % Image show
        if i == SR_Original_Index
            Image_LIMC = Data_Recovered_LIMC;
        end
        %%%-----------------------------Different Algorithms-----------------------------%%%

    end
    
    
%% Save results
    save Fig_6_Table_1
    
    
%% File address
    File_Address = 'Fig_6_Table_1\';
    mkdir('Fig_6_Table_1')
    
    
%% Text results
    disp('The PSNR results are as follows: ' )
    disp( PSNR_All )
    disp('The SSIM results are as follows: ' )
    disp( SSIM_All )
    disp('The CPUTime results are as follows: ' )
    disp( CPUTime_All )
  
    
%% Figure results
    figure
  % Original image
    h = Image_Synthesizer(uint8(Data_Original), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title('Original image')
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Original-Image-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'Original-Image-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
  % Masked image
    h = Image_Synthesizer(uint8(M_Omega), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title('Masked image')
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Masked-Image-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'Masked-Image-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
  % IRLS
    h = Image_Synthesizer(uint8(Image_IRLS), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title(['IRLS(' num2str(PSNR_All(1, SR_Original_Index))  ' | ' num2str(SSIM_All(1, SR_Original_Index)) ')'] )
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'IRLS-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'IRLS-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
  % PSSV
    h = Image_Synthesizer(uint8(Image_PSSV), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title(['PSSV(' num2str(PSNR_All(2, SR_Original_Index))  ' | ' num2str(SSIM_All(2, SR_Original_Index)) ')'] )
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'PSSV-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'PSSV-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
  % LTVNN
    h = Image_Synthesizer(uint8(Image_LTVNN), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title(['LTVNN(' num2str(PSNR_All(3, SR_Original_Index))  ' | ' num2str(SSIM_All(3, SR_Original_Index)) ')'] )
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'LTVNN-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'LTVNN-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
  % SPC-TV
    h = Image_Synthesizer(uint8(Image_SPC_TV), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title(['LTVNN(' num2str(PSNR_All(4, SR_Original_Index))  ' | ' num2str(SSIM_All(4, SR_Original_Index)) ')'] )
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'SPC_TV-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'SPC_TV-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
  % SPC-QV
    h = Image_Synthesizer(uint8(Image_SPC_QV), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title(['LTVNN(' num2str(PSNR_All(5, SR_Original_Index))  ' | ' num2str(SSIM_All(5, SR_Original_Index)) ')'] )
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'SPC_QV-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'SPC_QV-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
  % LIMC
    h = Image_Synthesizer(uint8(Image_LIMC), Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window);
    title(['LTVNN(' num2str(PSNR_All(6, SR_Original_Index))  ' | ' num2str(SSIM_All(6, SR_Original_Index)) ')'] )
    % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
    % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'LIMC-' num2str(SR_Original_Set(SR_Original_Index)) '.jpg'])
    saveas(gcf, [File_Address 'LIMC-' num2str(SR_Original_Set(SR_Original_Index)) '.fig'])
    
    figure
    % Original image
    subplot(2, 4, 1)
    imshow(Data_Original/255)
    title('Original image')
    % Masked image
    subplot(2, 4, 2)
    imshow(M_Omega/255)
    title('Masked image')
    % IRLS
    subplot(2, 4, 3)
    imshow(Image_IRLS/255)
    title(['IRLS(' num2str(PSNR_All(1, SR_Original_Index))  ' | ' num2str(SSIM_All(1, SR_Original_Index)) ')'] )
    % PSSV
    subplot(2, 4, 4)
    imshow(Image_PSSV/255)
    title(['PSSV(' num2str(PSNR_All(2, SR_Original_Index))  ' | ' num2str(SSIM_All(2, SR_Original_Index)) ')'] )
    % LTVNN
    subplot(2, 4, 5)
    imshow(Data_Recovered_LTVNN/255)
    title(['LTVNN(' num2str(PSNR_All(3, SR_Original_Index))  ' | ' num2str(SSIM_All(3, SR_Original_Index)) ')'] )
    % SPC-TV
    subplot(2, 4, 6)
    imshow(Data_Recovered_SPC_TV/255)
    title(['SPC-TV(' num2str(PSNR_All(4, SR_Original_Index))  ' | ' num2str(SSIM_All(4, SR_Original_Index)) ')'] )
    % SPC-QV
    subplot(2, 4, 7)
    imshow(Data_Recovered_SPC_QV/255)
    title(['SPC-QV(' num2str(PSNR_All(5, SR_Original_Index))  ' | ' num2str(SSIM_All(5, SR_Original_Index)) ')'] )
    % LIMC
    subplot(2, 4, 8)
    imshow(Image_LIMC/255)
    title(['Ours(' num2str(PSNR_All(6, SR_Original_Index))  ' | ' num2str(SSIM_All(6, SR_Original_Index)) ')'] )
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Demo-All.jpg'])
    saveas(gcf, [File_Address 'Demo-All.fig'])
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions_MC);
   rmpath(PATH_Functions_SPC);
   
   
    