function X_Sharp = LTVNN(m, n, Omega, M_Omega, gamma, Parameters)
%% Solver for following problem: 
 % X_Sharp = argmin_{X} (1-\gamma)*\|X\|_{*} + \gamma\|X\|_{LTVA} s.t. X_{Omega} = M_{Omega}
 % ---where \simga_{i}(X) is the i-th largest singular value of X
 % Here (M_{\Omega})_{ij}=M_{ij} if (i,j)\in\Omega and o otherwise
 % For more details see "Linear Total Variation Approximate Regularized
 % Nuclear Norm Optimization for Matrix Completion", Abstract and Applied
 % Analysis, volume 2014, article ID 765782

 
%% Author
 % Author: Dong Sylan(d.sylan@foxmail.com)


%% Set parameters
   k              = min(m, n);
   lambda         = 1;
   Unknown        = 1 - Omega;
   MaxIter        = 500;
   epsilon        = 1e-3;
 % ------------------Default ones------------------ %
 % Column TV
   In             = eye(n);
   XC_i           = M_Omega;
   WC_i           = XC_i;
   YC_i           = XC_i;
   MaxIter_Column = MaxIter;
   epsilon_Column = epsilon;
 % Row TV
   Im             = eye(m);
   XR_i           = M_Omega;
   WR_i           = XR_i;
   YR_i           = XR_i;
   MaxIter_Row    = MaxIter;
   epsilon_Row    = epsilon;
 % -------------------------------------- Setting ones -------------------------------------- %
   if isfield(Parameters, 'lambda');        lambda         = Parameters.lambda;          end
 % Column TV
   if isfield(Parameters, 'MaxIter_Column'); MaxIter_Column = Parameters.MaxIter_Column; end
   if isfield(Parameters, 'epsilon_Column'); epsilon_Column = Parameters.epsilon_Column; end
   if isfield(Parameters, 'Matrix_Column');  Matrix_Column  = Parameters.Matrix_Column;  end
 % Column TV
   if isfield(Parameters, 'MaxIter_Row');    MaxIter_Row    = Parameters.MaxIter_Row;    end
   if isfield(Parameters, 'epsilon_Row');    epsilon_Row    = Parameters.epsilon_Row;    end
   if isfield(Parameters, 'Matrix_Row');     Matrix_Row     = Parameters.Matrix_Row;     end
 % -------------------------------------- Setting ones -------------------------------------- %


%% ADMM strategy for Column TV
    for i = 1:MaxIter_Column
        
      % Update XC
        G  = WC_i + YC_i/lambda;
        [S, V, D] = svd( G );
        v = diag(V);
        % Based on Prox_L1
        xc_v = max(v - (1-gamma)/lambda, 0);
        XC_iPLUS = S(:, 1:k)*diag(xc_v)*D(:, 1:k)';

      % Update WC
        B_Column = lambda*XC_iPLUS - YC_i;
        A_Column = 2*gamma*Matrix_Column + lambda*In;
        WC_iPLUS = B_Column/A_Column;
        WC_iPLUS = WC_iPLUS.*Unknown + M_Omega;

      % Update YC
        YC_iPLUS = YC_i + lambda*(WC_iPLUS - XC_iPLUS);

      % Stopping criterion for Column TV
        if (i >= 2) && (norm(XC_iPLUS - XC_i, 'fro')/max(norm(XC_i, 'fro'), 1) <= epsilon_Column);
            break
        else
            XC_i = XC_iPLUS;
            YC_i = YC_iPLUS;
            WC_i = WC_iPLUS;
        end
        
    end
    X_Sharp_Column = XC_iPLUS;  
    
    
%% ADMM strategy for Row TV
    for i = 1:MaxIter_Row
        
      % Update XR
        G  = WR_i + YR_i/lambda;
        [S, V, D] = svd( G );
        v = diag(V);
        % Based on Prox_L1
        xr_v = max(v - (1-gamma)/lambda, 0);
        XR_iPLUS = S(:, 1:k)*diag(xr_v)*D(:, 1:k)';

      % Update WR
        B_Row = lambda*XR_iPLUS - YR_i;
        A_Row = 2*gamma*Matrix_Row + lambda*Im;
        WR_iPLUS = A_Row\B_Row;
        WR_iPLUS = WR_iPLUS.*Unknown + M_Omega;

      % Update YR
        YR_iPLUS = YR_i + lambda*(WR_iPLUS - XR_iPLUS);

      % Stopping criterion for Row TV
        if (i >= 2) && (norm(XR_iPLUS - XR_i, 'fro')/max(norm(XR_i, 'fro'), 1) <= epsilon_Row);
            break
        else
            XR_i = XR_iPLUS;
            YR_i = YR_iPLUS;
            WR_i = WR_iPLUS;
        end
        
    end
    X_Sharp_Row = XR_iPLUS;
    
    
%% Results
    X_Sharp = (X_Sharp_Column + X_Sharp_Row)/2;
    
end
   
   
   