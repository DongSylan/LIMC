function [Value_PSNR, SE] = PSNR(X_Original, X_recovered, PSNR_PixelIndex)
%% Compute the PSNR between two images
  % Make sure that 
  % ---1: all the values in X_Original and X_recovered must belong to [0, 255];
  % ---2: X_Original and X_recovered stand for two different images.
  
  
%% Author
 % Author: Dong Sylan(d.sylan@foxmail.com)
 

    p = size(X_Original, 3);
  % Compute SE
    SE = 0;
    for i =1:p
        SE = SE + norm( ( X_Original(:,:,i) - X_recovered(:,:,i) ).*PSNR_PixelIndex, 'fro')^2;
    end
  % Compute MSE
    MSE = SE/(p*nnz(PSNR_PixelIndex));
  % Compute PSNR
    Value_PSNR = 10*log10(255^2/MSE);
   
end