function [X_Sharp, Error_OuterIter] = PSSV(m, n, Omega, M_Omega, r, Parameters)

%% Solver for following problem: 
 % X_Sharp = argmin_{X} \|X\|_{N=r} s.t. X_{Omega} = M_{Omega}
 % ---where \|X\|_{N=r}=sum_{i=r+1}^{\min{m, n}}\sigma(X)
 % ---\simga_{i}(X) is the i-th largest singular value of X
 % see "Partial Sum Minimization of Singular Values in Robust PCA: Algorithm and Applications"
 %   IEEE Transaction on Pattern Analysis and machine Intelligence, vol 38, No 4, 2016.
 

%% Author
 % Author: Dong Sylan(d.sylan@foxmail.com)


%% Set parameters
   k = min(m, n);
   Unknown =  1 - Omega;
 % Default ones
   X_i     = M_Omega;
   Y_i     = X_i;
   Z_i     = zeros(m, n);
   rho     = 1e-3;
   MaxIter = 500;
   epsilon = 1e-3;
 % Setting ones
   if isfield(Parameters, 'X_i');          X_i     = Parameters.X_i; end
   if isfield(Parameters, 'Y_i');          Y_i     = Parameters.Y_i; end
   if isfield(Parameters, 'Z_i');          Z_i     = Parameters.Z_i; end
   if isfield(Parameters, 'rho');          rho     = Parameters.rho; end
   if isfield(Parameters, 'MaxIter');      MaxIter = Parameters.MaxIter; end
  if isfield(Parameters, 'epsilon');       epsilon = Parameters.epsilon; end


%% ADMM method for PSNNM
    Error_Set = zeros(MaxIter, 1);
    for i = 1:MaxIter
        
      % Update X
        G = Y_i - Z_i/rho;
        [U, D, V] = svd(G); 
      % We denote G = G1 + G2 where 
      %-- G1 = U(:, 1:r)*D(1:r, 1:r)*V(:, 1:r),
      %-- G2 = U(:, (r+1):k)*D((r+1):k, (r+1):k)*V(:, (r+1):k);
        d = diag(D);
        G1 = U(:, 1:r)*diag(d(1:r))*V(:, 1:r)';
        U_G2 = U(:, (r+1):k);
        V_G2 = V(:, (r+1):k);
        d_G2 = d((r+1):k);
      % Prox Lqq
        t_Sharp = max(d_G2 - 1/rho, 0);
        X_iPLUS = G1 + U_G2*diag(t_Sharp)*V_G2';
        
      % Update Y
        H = X_iPLUS + Z_i/rho;
        Y_iPLUS = M_Omega + H.*Unknown;
       
      % Update Z
        Z_iPLUS = Z_i + rho*(X_iPLUS - Y_iPLUS);

      % Stopping criterion
        Error_i = norm(X_iPLUS - X_i, 'fro')/max(norm(X_i, 'fro'), 1); 
        if (i >= 2) && (Error_i < epsilon)
            break
        else
            X_i = X_iPLUS;
            Y_i = Y_iPLUS;
            Z_i = Z_iPLUS;
            rho = min(1.05*rho, 1e3);
        end
        Error_Set(i) = Error_i;
   
    end
    X_Sharp = X_iPLUS;
    Error_OuterIter = Error_Set(1:i);
   
end
   
   
   