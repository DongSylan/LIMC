function X_Sharp = LIMC_Ecnomic(m, n, Omega, M_Omega, lambda, RmRmt, RnRnt, Parameters)

%% Solver for following problem: 
 % LIMC is short for Local Information aided MC
 % [EXACT] X_Sharp = argmin_{X} \|X\|_{*} + lambda*(\|X*R_{n}\|_{F}^{2}+\|X^{T}*R_{m}\|_{F}^{2})   s.t.   X_{Omega} = M_{Omega}
 %                        where \|X\|_{*}=sum_{i=1}^{k}(sigma_{i}(X))

%% Author
 % Author: Dong Sylan(d.sylan@foxmail.com)


%% Set parameters
   In       = eye(n);
   k        = min(m, n);
   Unknown  =  1 - Omega;
 % Default ones
   X_i      = M_Omega;
   Y_i      = X_i;
   Z_i      = zeros(m, n);
   rho      = 1e-2;
   MaxIter  = 500;
   epsilon  = 1e-4;
   % --- 
 % Setting ones
   if isfield(Parameters, 'X_i');          X_i     = Parameters.X_i;     end
   if isfield(Parameters, 'Y_i');          Y_i     = Parameters.Y_i;     end
   if isfield(Parameters, 'Z_i');          Z_i     = Parameters.Z_i;     end
   if isfield(Parameters, 'rho');          rho     = Parameters.rho;     end
   if isfield(Parameters, 'MaxIter');      MaxIter = Parameters.MaxIter; end
   if isfield(Parameters, 'epsilon');      epsilon = Parameters.epsilon; end
   lambda_rho = lambda/rho;
   
    
%% ADMM method for LIMC
    for i = 1:MaxIter

      % Update X
        G = Y_i - Z_i/rho;
        [S, V, D] = svd(G); 
        v = diag(V);
        x_v = max(v - 1/rho, 0);
        X_iPLUS = S(:, 1:k)*diag(x_v)*D(:, 1:k)';

      % Compute the relative error on X
        ErrorType1_i   = norm(X_iPLUS - X_i, 'fro')/max(norm(X_i, 'fro'), 1); 
        
      % Update Y
        H = X_iPLUS + Z_i/rho;
        Y_widehat = lyap(2*lambda_rho*RmRmt, 2*lambda_rho*RnRnt + In, -H);
        Y_iPLUS = M_Omega + Y_widehat.*Unknown;

      % Update Z
        Z_iPLUS = Z_i + rho*(X_iPLUS - Y_iPLUS);

      % Stopping criterion
        if (i >= 2) && (ErrorType1_i <= epsilon)
            break
        else
            X_i = X_iPLUS;
            Y_i = Y_iPLUS;
            Z_i = Z_iPLUS;
            rho = min(1.05*rho, 1e3);
        end
   
    end
    X_Sharp = X_iPLUS;
    
end
   
   
   