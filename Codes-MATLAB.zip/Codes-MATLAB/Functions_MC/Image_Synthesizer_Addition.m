function h = Image_Synthesizer_Addition(Image_Original, Position_Window, Imresize_Ratio, Location_Image_Resized, Color_Window, LineStyle_Window)

   [m_Image_Original, n_Image_Original] = size(Image_Original);
   % I2 = imcrop(I,RECT) % [XMIN YMIN WIDTH HEIGHT]
 % Cuted iamge
   Image_Local = imcrop(Image_Original, Position_Window);
 % Resized image
   Image_Resized = imresize(Image_Local, Imresize_Ratio);
 % Location for resized image
   [m_Image_Resized, n_Image_Resized] = size(Image_Resized);
   
   rectangle('Position', Position_Window, 'EdgeColor', Color_Window, 'LineWidth', 2, 'LineStyle' , LineStyle_Window)
   hold on
   h = 1;
   switch Location_Image_Resized 
       case 'LeftTop'  
           x = 3;
           y = 3;
       case 'RightTop'
           x = m_Image_Original - m_Image_Resized - 1;
           y = 3;
       case 'LeftBottom'
           x = 3;
           y = n_Image_Original - n_Image_Resized - 1;
       case 'RightBottom'
           x = m_Image_Original - m_Image_Resized - 1;
           y = n_Image_Original - n_Image_Resized - 1;
       otherwise
           h = 0;
           disp('Please check your inputs carefully when you are using function ''Image_Show.m''.')
           close all 
           return
   end
   imshow(Image_Resized, 'XData', [x, m_Image_Resized + x - 1], 'YData', [y, n_Image_Resized + y - 1]);
   Position_Image = [x - 1,  y - 1,  m_Image_Resized + 1,  n_Image_Resized + 1];
   rectangle('Position', Position_Image, 'EdgeColor', Color_Window, 'LineWidth', 4, 'LineStyle', LineStyle_Window)

   
end

