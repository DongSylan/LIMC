%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Load the data and toolbox
  % Load the data
    Name_Image        = 'Lenna.jpg';
    Image_Gray        = imread(Name_Image);
    Data_Original     = double(Image_Gray);
  % Load the toolbox of functions for MC
    PATH_Functions_MC = genpath('Functions_MC');
    addpath(PATH_Functions_MC);

   
%% Public parameter setting 
    M = Data_Original;
    [m, n] = size(M);
  % Sampling Ratio on original image
    SR_Original = 40;
    Index = randi(100, m, n);
    Omega = Index < SR_Original;
    M_Omega = M.*Omega;
    Unknown = 1 - Omega;

   
%% Parameter setting for algorithms
    lambda_LIMC        = 1e-4;
    Rm                 = diag(ones(m-1, 1), 1) + diag(ones(m-1, 1), -1)  - 2*eye(m);
    Rm(1, 1)           = -1;   
    Rm(m, m)           = -1; 
    RmRmt              = Rm*Rm';
    Rn                 = diag(ones(n-1, 1), 1) + diag(ones(n-1, 1), -1)  - 2*eye(n);
    Rn(1, 1)           = -1;   
    Rn(n, n)           = -1; 
    RnRnt              = Rn*Rn';
    Para_LIMC.M        = M;
    Para_LIMC.rho      = 1e-2;
    Para_LIMC.MaxIter  = 1000;
    Para_LIMC.epsilon  = 1e-9;
    
    
%% Main
  % LIMC
    tic
    [Data_Recovered_LIMC, RelaError_NeigXiXiPLUS, RelaError_NeigMXiPLUS] = LIMC(m, n, Omega, M_Omega, lambda_LIMC, RmRmt, RnRnt, Para_LIMC);
    CPUTime_LIMC = toc;
    % Output of LIMC
    Data_Recovered_LIMC = max(Data_Recovered_LIMC, 0);
    Data_Recovered_LIMC = min(Data_Recovered_LIMC, 255);
    Data_Recovered_LIMC = M_Omega + Data_Recovered_LIMC.*Unknown;

    
%% Save results
    save Fig_5
    

%% File address
    File_Address = 'Fig_5\';
    mkdir('Fig_5')  
    
    
%% Results
    figure
    h_NeigXiXiPLUS = plot(log10(RelaError_NeigXiXiPLUS));
    set(h_NeigXiXiPLUS, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 4);
    xlim([0, 500])
    xlabel('k', 'FontWeight', 'bold', 'FontSize', 20)
    ylabel('log_{10}n(k)', 'FontWeight', 'bold', 'FontSize', 20)
    grid on
%     ylabel('$\lg\frac{\|X^{(t+1)}-X^{(t)}\|_{F}}{\max\{\|X^{(t)}\|_{F}, 1\}}$', 'Interpreter', 'latex', 'FontWeight', 'bold', 'FontSize', 20)
    set(gca,'FontSize', 20, 'FontWeight','bold', 'XTick', 0:100:500, 'position', [0.15, 0.2, 0.7, 0.7])  
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'RelaError_NeigXiXiPLUS.jpg'])
    saveas(gcf, [File_Address 'RelaError_NeigXiXiPLUS.fig'])
    
    figure
    h_NeigMXiPLUS = plot(log10(RelaError_NeigMXiPLUS));
    set(h_NeigMXiPLUS, 'Color', 'r', 'LineStyle', '-', 'LineWidth', 4);
    xlim([0, 500])
    xlabel('k', 'FontWeight', 'bold', 'FontSize', 20)
    ylabel('log_{10}t(k)', 'FontWeight', 'bold', 'FontSize', 20)
    grid on
%     ylabel('$\lg\frac{\|M-X^{(t)}\|_{F}}{\|M\|_{F}}$', 'Interpreter', 'latex', 'FontWeight', 'bold', 'FontSize', 20)
    set(gca, 'FontSize', 20, 'FontWeight','bold', 'XTick', 0:100:500, 'position', [0.15, 0.2, 0.7, 0.7]) 
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'RelaError_NeigMXiPLUS.jpg'])
    saveas(gcf, [File_Address 'RelaError_NeigMXiPLUS.fig'])
    
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions_MC);
   
   
    