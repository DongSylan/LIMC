%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Main
    Name_Image      = 'Lenna.jpg';
    Image_Gray      = imread(Name_Image);
    Data_Gray       = double(Image_Gray);
    Vec_SinguValues = svd(Data_Gray);
    n               = length(Vec_SinguValues);
    D               = tril(ones(n, n), 0);
    Ratios          = D*Vec_SinguValues/sum(Vec_SinguValues);
    find(Ratios > 0.8, 1)
    
    
%% File address
    File_Address = 'Fig_1\';
    mkdir('Fig_1') 
    
    
%% Figures
    figure
    imshow(Image_Gray)
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Gray-Image.jpg'])
    saveas(gcf, [File_Address 'Gray-Image.fig'])
    
    figure
    h_Data_Gray = plot(svd(Data_Gray));
    set(h_Data_Gray, 'Color', 'k', 'LineStyle', '-', 'LineWidth', 2, 'MarkerSize', 10);
    xlim([0, 300])
%     xlabel('Index of singular value', 'FontWeight', 'bold', 'FontSize', 20);
%     ylabel('Magnitude of singular value', 'FontWeight', 'bold', 'FontSize', 20)
    xlabel('i', 'FontWeight', 'bold', 'FontSize', 20);
    ylabel('\sigma_{i}(\cdot)', 'FontWeight', 'bold', 'FontSize', 20)
    set(gca,'FontSize', 20, 'FontWeight','bold', 'XTick', 0:50:300, 'position', [0.25, 0.2, 0.5, 0.6])   % 'position', [left��bottom��width��height]
    grid on
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Singular-Values.jpg'])
    saveas(gcf, [File_Address 'Singular-Values.fig'])
    
    
    
    

    
    