%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')

    
%% Load the data
  % Load the text image
    Name_Cover = 'Text_Image.jpg';
    Data_Cover = double(imread(Name_Cover));  % 0 menas black 255 means white
  % Construct the image with test
    Omega = Data_Cover > 200;
    Unknown = ~Omega;
    
    
%% Main
    Gray_Imgaes = uint8(zeros(256*2, 256*10));
    k = 1;
    for i = 1:2
        iIndex = (256*(i-1) + 1):(256*i);
        for j = 1:10
            jIndex = (256*(j-1) + 1):(256*j);
            % Load the data
            if k < 10
                Name_Pic = ['Images-Gray\0' num2str(k)  '.jpg'];
            else
                Name_Pic = ['Images-Gray\' num2str(k)  '.jpg'];
            end
            Image_Gray_ij = double(imread(Name_Pic));
            Gray_Imgaes(iIndex, jIndex, :) = Image_Gray_ij.*Omega;
            k = k + 1;
        end
    end
    
    
%% File address
    File_Address = 'Fig_8\';
    mkdir('Fig_8')  
    
    
%% Results
    imshow(Gray_Imgaes)
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Gray_Imgaes.jpg'])
    saveas(gcf, [File_Address 'Gray_Imgaes.fig'])
    
    
    
    
    
    
    
    
    