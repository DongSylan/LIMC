function v = sum_all(Z)

v = sum(Z(:));
