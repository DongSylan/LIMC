%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% File: SPC
% Time: Sep. 7th, 2015.
% 
% Smooth modeling for incomplete tensor by the PARAFAC decomposition.
% This algorithm is proposed in
%  "Yokota, Tatsuya, et al. "Smooth PARAFAC Decomposition for Tensor Completion." arXiv:1505.06611 (2015)."
%
% minimize R, s.t. || T.*Q - Z.*Q ||_F^2 < epsiron,
%
% where,   Z = [G; U{1}, U{2}, ..., U{N}],
%          U{n} are smooth factor matrices with smoothness rho(n).
%
% Inputs
% - T       : N-way incomplete tensor
% - Q       : binary tensor which represents elements are available or not (available:1, missing:0)
% - TV_QV   : it take 'tv' or 'qv' for selecting types of smoothing
% - rho     : N-dimensional vector which represents smoothness of individual modes
% - K       : accelerate parameter for fast optimization (small for fast <--> large for slow, typically 10)
% - SNR     : error threshold via signal-to-noise ratio
% - rate    : 'nu' in paper, stopping threshold of fixed-rank approximation (large for fast <--> small for slow, typically 0.01)
% - maxiter : maximum number of iteration
% - tol     : tolerance parameter for convergence evaluation
% - out     : 1 for image completion, 0 for the others
%
% Outputs
% - X       : Results of tensor completion X, where X(Q) = T and X(~Q) = Z
% - Z       : Results of smooth PARAFAC decomposition Z
% - G       : Results of core values G
% - U       : Results of factor matrices U
% - histo   : optimization behavior of error || T.*Q - Z.*Q ||_F^2
% - histo_R : optimization behavior of number of components R
%
% This code was implemented by Tatsuya Yokota
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X Z G U histo histo_R] = SPC(T,Q,TV_QV,rho,K,SNR,rate,maxiter,tol,out)

  maxR = inf;

  warning off; 

  histo=[];
  histo_R=[];
  N  = ndims(T);
  II = size(T);
  NN = sum(Q(:));
  epsiron = 10^(-SNR/10) * sum_all(T(Q).^2);

  %% initialization
%   E  = zeros(II);
  X  = zeros(II);
  Z  = zeros(II);
%   ONE= zeros(II);

  R  = 1;

  X(Q) = T(Q);
  X(~Q) = sum(X(:))/NN;
  for n = 1:N
    Pp  = eye(II(n)-1,II(n));
    Pm  = eye(II(n)); Pm(1,:) = [];
    P{n} = Pp - Pm;
    
%   %----------Our Improvement----------%
%     Ln               = diag(ones(II(n)-1, 1), 1) + diag(ones(II(n)-1, 1), -1)  - 2*eye(II(n));
%     Ln(1, 1)         = -1;   
%     Ln(II(n), II(n)) = -1; 
%     P{n}             = Ln;
%   %----------Our Improvement----------%
    
    PtP{n} = P{n}'*P{n};
    PtPI{n} = rho(n)*PtP{n} + eye(II(n));
    Pr{n} = inv(rho(n)*PtP{n} + eye(II(n)));
    U{n} = Pr{n}*randn(II(n),R);
    U{n} = U{n}/norm(U{n});
  end

  G = tensor_allprod(X,U,1);
  for r = 1:R
    Z = Z + G(r)*outerprod(U,r);
  end
  obj = sum_all((T(Q) - Z(Q)).^2);
  X(~Q) = Z(~Q);
  E = X - Z;

  %% output some figures

%   h1 = figure();clf;
%   subplot(1,2,1);cla;hold on;
%   subplot(1,2,2);
%   drawnow;
%   if out == 1
%     h2 = figure();clf;
%     imagesc(uint8(X));drawnow;
%     imwrite(uint8(X),['saved/' TV_QV '_iter_0.png']);
%   end
%   if out > 1
%     h2 = figure();clf;
%   end
% 
%   fprintf('iter:  objective :: epsilon :: conv. speed :: number of components \n');

  %% start main algorithm
  for iter = 1:maxiter

    [val ID] = sort(abs(G));
    for k = ID(1:min(end,K))
  
      ONE = G(k)*outerprod(U,k);
      Z = Z - ONE;
      E = E + ONE;

      div = 1;
      for n = 1:N

        if strcmp(TV_QV, 'tv') 

          u = innerprod_one_exc(E,U,k,n);
          u = u(:);
          %initilization
          a = u/norm(u);
          % main iteration for constrained version
          object = 0.5*G(k)^2*rho(n)*sum(abs(P{n}*a)) - G(k)*a'*u;
          for nn = 1:1000
            df = P{n}'*sign(P{n}*a);
            dL = (0.5*G(k)^2*rho(n)*df - G(k)*u + G(k)^2*a)/G(k)^2;
            al = [0 0.1 0.01 0.001 0.0001 0.00001];
            for ai = 1:length(al)
              a2 = a - al(ai)*dL;
              a2 = a2/norm(a2);
              score(ai) = 0.5*G(k)^2*rho(n)*sum(abs(P{n}*a2)) - G(k)*a2'*u;
            end
            [object2 ai] = min(score);
            a2 = a - al(ai)*dL;
            a2 = a2/norm(a2);
            if abs(object2 - object)/II(n) < 1e-3
              break;
            else
              a = a2;
              object = object2;
            end
          end
          lam = norm(a);
          u = a/lam;
          U{n}(:,k) = u;
          v{n} = u;
          div  = div + rho(n)*sum(abs(P{n}*u));

        elseif strcmp(TV_QV,'qv')

          u = innerprod_one_exc(E,U,k,n);
          u = u(:);
          % initialization
          a = Pr{n}*u;
          a = a/norm(a);
          % main iteration for constrained version
          object = 0.5*G(k)^2*rho(n)*a'*PtP{n}*a - G(k)*a'*u;
          mu = 0.1;
          for nn = 1:1000
            dL = (G(k)^2*PtPI{n}*a - G(k)*u)/G(k)^2;
            al = [0 0.1 0.01 0.001 0.0001 0.00001];
            for ai = 1:length(al)
              a2 = a - al(ai)*dL;
              a2 = a2/norm(a2);
              score(ai) = 0.5*G(k)^2*rho(n)*a2'*PtP{n}*a2 - G(k)*a2'*u;
            end
            [object2 ai] = min(score);
            a2 = a - al(ai)*dL;
            if abs(object2 - object)/II(n) < 1e-3
              break;
            else
              a = a2;
              object = object2;
            end
          end

          u = a2;
          lam = norm(u);
          u = u/lam;
          U{n}(:,k) = u;
          v{n} = u;
          div  = div + rho(n)*u'*PtP{n}*u;

        else
          error('2rd input is ''tv'' or ''qv'' ');
        end

      end

      G(k) = tensor_allprod(E,v,1)/div;

      if G(k) < 0
        G(k) = -G(k);
        U{1}(:,k) = - U{1}(:,k);
      end

      ONE = G(k)*outerprod(U,k);
      E = E - ONE;
      E(~Q) = 0;
      Z = Z + ONE;
      X(~Q) = Z(~Q);

    end
   
    %% calculate MSE
    obj2 = sum_all(E.^2);

    %% convergence speed
    speed = abs(obj2 - obj)/abs(epsiron - obj2);

    %% step for R <-- R + 1
    if speed < rate || abs(obj2-obj)/NN < tol

      if R ~= maxR

      R = R + 1;
      for n = 1:N
        u = Pr{n}*randn(II(n),1);
        u = u/norm(u);
        U{n}(:,R) = u;
        v{n} = u;
      end
      G(R) = tensor_allprod(E,v,1);
      E = E - G(R)*outerprod(U,R);
      E(~Q) = 0;

      else
        break;
      end
      
    end

    %% checking convergence
    if obj2 < epsiron
      break;
    else
      obj = obj2;
%       if mod(iter,5)==0
%         fprintf('%d:  %f :: %f :: %f :: R= %d \n',iter,obj2/NN,epsiron/NN,speed,R);
%       end
      histo(iter) = obj;
      histo_R(iter,:) = size(G);
    end

%     %% output figures
%     set(0,'CurrentFigure',h1);
%     subplot(1,2,1);cla;hold on;
%     plot((histo));
%     plot((epsiron)*ones(1,length(histo)))
%     grid on;
%     set(gca,'YScale','log')
%     title('MSE')
%     subplot(1,2,2);
%     plot(histo_R(:,2));
%     title('number of components R')
%     
%     drawnow;
%     if out == 1
%       set(0,'CurrentFigure',h2);
%       %imagesc(uint8(X));
%       imagesc(uint8(Z));
%       title(['Number of R = ' num2str(R)]);
%       drawnow;
%     end
% 
%     if mod(iter,10) == 0 & out == 1
%       imwrite(uint8(Z),['saved/' TV_QV '_iter_' num2str(iter) '.png']);
%     end

%     if mod(iter,100) == 0
%       pack;
%     end

  end


