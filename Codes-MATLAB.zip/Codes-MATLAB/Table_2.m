%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Load the data and toolbox
    Name_ImagesFile   = 'Images-Gray';
  % Load the Images
    Dir_Images        = dir(fullfile(Name_ImagesFile, '*.jpg'));
    Name_Images       = {Dir_Images.name};
    Num_Images        = length(Name_Images);
  % Load the functions
    PATH_Functions_MC = genpath('Functions_MC');
    addpath(PATH_Functions_MC);
    
    
%% Public parameter setting 
  % Image size
    m               = 256; 
    n               = 256;
  % epsilon
    epsilon         = 1e-4;
  % MaxIter
    MaxIter         = 500; 
  % Observed ratios
    SR_Original_Set = [30 40 45 50]; 
  % Number of independent trials
    Num_Trials = 5;


%% Parameter setting for algorithms
  % IRLS
    lambda_IRLS           = 1e-4;
    q_IRLS                = 0.5; 
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.rank_adjust = 1;     
    Para_IRLS.rank        = 20;
    Para_IRLS.min_rank    = 5;    
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.maxit       = MaxIter;
    Para_IRLS.tol         = 1e-5;
    
  % PSSV
    Para_PSSV.rho     = 1e-3;
    % Stopping rules 
    Para_PSSV.MaxIter = MaxIter;
    Para_PSSV.epsilon = epsilon;
    
  % LTVNN
    gamma_LTVNN               = 0.5;
    Para_LTVNN.lambda         = 1e0;
    % Parameters for Column TV 
    Para_LTVNN.MaxIter_Column = MaxIter;
    Para_LTVNN.epsilon_Column = epsilon;
    In                       = eye(n);
    e_n_1                    = [zeros(n-2, 1); 1];
    phi1                     = [zeros(1, n); [eye(n-1), e_n_1]];
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    Para_LTVNN.Matrix_Column  = In - phi1 - phi1' + phi1*phi1'; 
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    % Parameters for Row TV 
    Para_LTVNN.MaxIter_Row    = MaxIter;
    Para_LTVNN.epsilon_Row    = epsilon;
    Im                       = eye(m);
    e_m_1                    = [zeros(m-2, 1); 1];
    phi2                     = [zeros(m, 1), [eye(m-1); e_m_1']];
    Para_LTVNN.Matrix_Row     = Im - phi2 - phi2' + phi2'*phi2;
    
  % SPC
    PATH_Functions_SPC = genpath('Function_SPC');
    addpath(PATH_Functions_SPC);
    K       = 10;          % Number of components which are updated in one iteration. (typically 10)
    SNR     = 30;          % error bound
    nu      = 0.01;        % threshold for R <-- R + 1.
    maxiter = MaxIter;     % maximum number of iteration
    tol     = 1e-5;        % tolerance
    out_im  = 1;           % you can monitor the process of 'image' completion if out == 1. 'saved' directory is necessary to save the individual rank images.
    %%%%%% ---- In image recovery problems, such as denoising and restoration, it is generally considered that the TV constraint is better than QV. ---- %%%%%%
    %--SPC-TV
    TV     = 'tv';        % 'tv' or 'qv' ;
    rho_TV = [0.01 0.01]; % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %--SPC-QV
    QV     = 'qv';        % 'tv' or 'qv' ;
    rho_QV = [0.5 0.5];   % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %%%%%% ----------- On the other hand, our result implies that the QV constraint performs better than TV for the image completion problem. ----------- %%%%%%%
    
  % LIMC
    lambda_LIMC       = 1e-4;
    Rm                = diag(ones(m-1, 1), 1) + diag(ones(m-1, 1), -1)  - 2*eye(m);
    Rm(1, 1)          = -1;   
    Rm(m, m)          = -1; 
    RmRmt             = Rm*Rm';
    Rn                = diag(ones(n-1, 1), 1) + diag(ones(n-1, 1), -1)  - 2*eye(n);
    Rn(1, 1)          = -1;   
    Rn(n, n)          = -1; 
    RnRnt             = Rn*Rn';
    Para_LIMC.rho     = 1e-2;
    Para_LIMC.MaxIter = MaxIter;
    Para_LIMC.epsilon = epsilon;
    
    
%% Parameters for variables
    Num_SR_Original = length(SR_Original_Set);
    PSNR_All        = zeros(Num_Images, 6, Num_SR_Original);
    SSIM_All        = zeros(Num_Images, 6, Num_SR_Original);
    CPUTime_All     = zeros(Num_Images, 6, Num_SR_Original);
    
    
%% Main 
  % The structure
    for i = 1:Num_Images
        i
      % Load the i-th image
        Name_Pic  = strcat([Name_ImagesFile '\'], Name_Images{i});
        Image_Color = imread(Name_Pic);
        Data_Original = double(Image_Color);
        M = Data_Original;
        [m, n] = size(M);
        
        for j = 1:Num_SR_Original
            SR_Original = SR_Original_Set(j);
            
            for k = 1:Num_Trials
                
              % Sampling on original image
                Index   = randi(100, m, n);
                Omega   = Index < SR_Original;
                M_Omega = M.*Omega;
                Unknown = 1 - Omega;
            
                %%%-----------------------------Different Algorithms-----------------------------%%%
              % IRLS
                tic
                Data_Recovered_IRLS = tIRucLq_m(m, n, Omega, M_Omega, lambda_IRLS, q_IRLS, Para_IRLS);
                CPUTime_IRLS = toc;
                % Output of IRLS
                Data_Recovered_IRLS = max(Data_Recovered_IRLS, 0);
                Data_Recovered_IRLS = min(Data_Recovered_IRLS, 255);
                Data_Recovered_IRLS = M_Omega + Data_Recovered_IRLS.*Unknown;
                % CPUTime
                CPUTime_All(i, 1, j) = CPUTime_All(i, 1, j) + CPUTime_IRLS/Num_Trials;
                % PSNR
                PSNR_All(i, 1, j)    = PSNR_All(i, 1, j) + PSNR(Data_Original, Data_Recovered_IRLS, Unknown)/Num_Trials;
                % SSIM
                SSIM_All(i, 1, j)    = SSIM_All(i, 1, j) + ssim_index(Data_Original, Data_Recovered_IRLS)/Num_Trials;;
            
              % PSSV
                PSNR_SSIM_Best = 0;
                CPUTime_PSSV = 0;
                for rank_estimate = 5:20
                    tic
                    Data_Recovered_PSSV = PSSV(m, n, Omega, M_Omega, rank_estimate, Para_PSSV);
                    CPUTime_rank = toc;
                    CPUTime_PSSV = CPUTime_PSSV + CPUTime_rank;
                    % Output of PSSV
                    Data_Recovered_PSSV = max(Data_Recovered_PSSV, 0);
                    Data_Recovered_PSSV = min(Data_Recovered_PSSV, 255);
                    Data_Recovered_PSSV = M_Omega + Data_Recovered_PSSV.*Unknown;
                    % PSNR-rank
                    PSNR_rank           = PSNR(Data_Original, Data_Recovered_PSSV, Unknown);
                    % SSIM-rank
                    SSIM_rank           = ssim_index(Data_Original, Data_Recovered_PSSV);
                    % PSNR-SSIM-rank
                    PSNR_SSIM_rank = PSNR_rank + 30*SSIM_rank;
                    if PSNR_SSIM_rank >= PSNR_SSIM_Best
                        PSNR_SSIM_Best = PSNR_SSIM_rank;
                        PSNR_Best = PSNR_rank;
                        SSIM_Best = SSIM_rank;
                    end
                end
                % CPUTime
                CPUTime_All(i, 2, j) = CPUTime_All(i, 2, j) + CPUTime_PSSV/Num_Trials;
                % PSNR
                PSNR_All(i, 2, j)    = PSNR_All(i, 2, j) + PSNR_Best/Num_Trials;
                % SSIM
                SSIM_All(i, 2, j)    = SSIM_All(i, 2, j) + SSIM_Best/Num_Trials;
            
              % LTVNN
                tic
                Data_Recovered_LTVNN = LTVNN(m, n, Omega, M_Omega, gamma_LTVNN, Para_LTVNN);
                CPUTime_LTVNN = toc;
                % Output of LTVNN
                Data_Recovered_LTVNN = max(Data_Recovered_LTVNN, 0);
                Data_Recovered_LTVNN = min(Data_Recovered_LTVNN, 255);
                Data_Recovered_LTVNN = M_Omega + Data_Recovered_LTVNN.*Unknown;
                % CPUTime
                CPUTime_All(i, 3, j) = CPUTime_All(i, 3, j) + CPUTime_LTVNN/Num_Trials;
                % PSNR
                PSNR_All(i, 3, j)    = PSNR_All(i, 3, j) + PSNR(Data_Original, Data_Recovered_LTVNN, Unknown)/Num_Trials;
                % SSIM
                SSIM_All(i, 3, j)    = SSIM_All(i, 3, j) + ssim_index(Data_Original, Data_Recovered_LTVNN)/Num_Trials;
            
              % SPC-TV
                tic
                Data_Recovered_SPC_TV = SPC(M_Omega, Omega, TV, rho_TV, K, SNR, nu, maxiter, tol, out_im);
                CPUTime_SPC_TV = toc;
                % Output of SPC-TV
                Data_Recovered_SPC_TV = max(Data_Recovered_SPC_TV, 0);
                Data_Recovered_SPC_TV = min(Data_Recovered_SPC_TV, 255);
                Data_Recovered_SPC_TV = M_Omega + Data_Recovered_SPC_TV.*Unknown;
                % CPUTime
                CPUTime_All(i, 4, j) = CPUTime_All(i, 4, j) + CPUTime_SPC_TV/Num_Trials;
                % PSNR
                PSNR_All(i, 4, j)    = PSNR_All(i, 4, j) + PSNR(Data_Original, Data_Recovered_SPC_TV, Unknown)/Num_Trials;
                % SSIM
                SSIM_All(i, 4, j)    = SSIM_All(i, 4, j) + ssim_index(Data_Original, Data_Recovered_SPC_TV)/Num_Trials;
            
              % SPC-QV
                tic
                Data_Recovered_SPC_QV = SPC(M_Omega, Omega, QV, rho_QV, K, SNR, nu, maxiter, tol, out_im);
                CPUTime_SPC_QV = toc;
                % Output of SPC-QV
                Data_Recovered_SPC_QV = max(Data_Recovered_SPC_QV, 0);
                Data_Recovered_SPC_QV = min(Data_Recovered_SPC_QV, 255);
                Data_Recovered_SPC_QV = M_Omega + Data_Recovered_SPC_QV.*Unknown;
                % CPUTime
                CPUTime_All(i, 5, j) = CPUTime_All(i, 5, j) + CPUTime_SPC_QV/Num_Trials;
                % PSNR
                PSNR_All(i, 5, j)    = PSNR_All(i, 5, j) + PSNR(Data_Original, Data_Recovered_SPC_QV, Unknown)/Num_Trials;
                % SSIM
                SSIM_All(i, 5, j)    = SSIM_All(i, 5, j) + ssim_index(Data_Original, Data_Recovered_SPC_QV)/Num_Trials;
            
              % LIMC
                tic
                Data_Recovered_LIMC = LIMC_Ecnomic(m, n, Omega, M_Omega, lambda_LIMC, RmRmt, RnRnt, Para_LIMC);
                CPUTime_LIMC = toc;
                % Output of LIMC
                Data_Recovered_LIMC = max(Data_Recovered_LIMC, 0);
                Data_Recovered_LIMC = min(Data_Recovered_LIMC, 255);
                Data_Recovered_LIMC = M_Omega + Data_Recovered_LIMC.*Unknown;
                % CPUTime
                CPUTime_All(i, 6, j) = CPUTime_All(i, 6, j) + CPUTime_LIMC/Num_Trials;
                % PSNR
                PSNR_All(i, 6, j)    = PSNR_All(i, 6, j) + PSNR(Data_Original, Data_Recovered_LIMC, Unknown)/Num_Trials;
                % SSIM
                SSIM_All(i, 6, j)    = SSIM_All(i, 6, j) + ssim_index(Data_Original, Data_Recovered_LIMC)/Num_Trials;
                %%%-----------------------------Different Algorithms-----------------------------%%%
                
            end
            
        end
        
    end
   
    
%% Save the results
    save Table_2
    
    
%% Results
    for i = 1:Num_SR_Original
        disp(['The PSNR results based on ' num2str(SR_Original_Set(i)) '% pixels are as follows: ' ])
        disp(PSNR_All(:, :, i))
        disp(['The SSIM results based on ' num2str(SR_Original_Set(i)) '% pixels are as follows: ' ])
        disp(SSIM_All(:, :, i))
        disp(['The CPUTime results based on ' num2str(SR_Original_Set(i)) '% pixels are as follows: ' ])
        disp( mean(CPUTime_All(:, :, i)) )
    end
    
    
%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions_MC);
   rmpath(PATH_Functions_SPC);
   
   
    