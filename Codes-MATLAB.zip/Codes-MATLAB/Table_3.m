%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Load the data and toolbox
    Name_ImagesFile   = 'Images-Gray';
  % Load the Images
    Dir_Images        = dir(fullfile(Name_ImagesFile, '*.jpg'));
    Name_Images       = {Dir_Images.name};
    Num_Images        = length(Name_Images);
  % Load the text image
    Name_Cover = 'Text_Image.jpg';
    Data_Cover = double(imread(Name_Cover));  % 0 menas black 255 means white
  % Construct the image with test
    Omega = Data_Cover > 200;
    Unknown = ~Omega;
  % Load the toolbox of functions for MC
    PATH_Functions_MC = genpath('Functions_MC');
    addpath(PATH_Functions_MC);
    
    
%% Public parameter setting
    [m, n]  = size(Data_Cover);
  % epsilon
    epsilon = 1e-4;
  % MaxIter
    MaxIter = 500;   
    

%% Parameter setting for algorithms
  % IRLS
    lambda_IRLS           = 1e-4;
    q_IRLS                = 0.5; 
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.rank_adjust = 1;     
    Para_IRLS.rank        = 20;
    Para_IRLS.min_rank    = 5;    
    % ------For rank of matrix to be completed------ % 
    Para_IRLS.maxit       = MaxIter;
    Para_IRLS.tol         = 1e-5;
    
  % PSSV
    Para_PSSV.rho     = 1e-3;
    % Stopping rules 
    Para_PSSV.MaxIter = MaxIter;
    Para_PSSV.epsilon = epsilon;
    
  % LTVNN
    gamma_LTVNN               = 0.5;
    Para_LTVNN.lambda         = 1e0;
    % Parameters for Column TV 
    Para_LTVNN.MaxIter_Column = MaxIter;
    Para_LTVNN.epsilon_Column = epsilon;
    In                        = eye(n);
    e_n_1                     = [zeros(n-2, 1); 1];
    phi1                      = [zeros(1, n); [eye(n-1), e_n_1]];
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    Para_LTVNN.Matrix_Column  = In - phi1 - phi1' + phi1*phi1'; 
    %%%%%---- The pseudocode in original paper is tatally wrong due to the form phi1'*phi1 ----%%%%%
    % Parameters for Row TV 
    Para_LTVNN.MaxIter_Row    = MaxIter;
    Para_LTVNN.epsilon_Row    = epsilon;
    Im                        = eye(m);
    e_m_1                     = [zeros(m-2, 1); 1];
    phi2                      = [zeros(m, 1), [eye(m-1); e_m_1']];
    Para_LTVNN.Matrix_Row     = Im - phi2 - phi2' + phi2'*phi2;
    
  % SPC
    PATH_Functions_SPC = genpath('Function_SPC');
    addpath(PATH_Functions_SPC);
    K       = 10;          % Number of components which are updated in one iteration. (typically 10)
    SNR     = 30;          % error bound
    nu      = 0.01;        % threshold for R <-- R + 1.
    maxiter = MaxIter;     % maximum number of iteration
    tol     = 1e-5;        % tolerance
    out_im  = 1;           % you can monitor the process of 'image' completion if out == 1. 'saved' directory is necessary to save the individual rank images.
    %%%%%% ---- In image recovery problems, such as denoising and restoration, it is generally considered that the TV constraint is better than QV. ---- %%%%%%
    %--SPC-TV
    TV     = 'tv';        % 'tv' or 'qv' ;
    rho_TV = [0.01 0.01]; % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %--SPC-QV
    QV     = 'qv';        % 'tv' or 'qv' ;
    rho_QV = [0.5 0.5];   % smoothness (0.1 - 1.0) for 'qv' and (0.01 - 0.5) for 'tv' is recommended.
    %%%%%% ----------- On the other hand, our result implies that the QV constraint performs better than TV for the image completion problem. ----------- %%%%%%
    
  % LIMC
    lambda_LIMC       = 1e-4;
    Rm                = diag(ones(m-1, 1), 1) + diag(ones(m-1, 1), -1)  - 2*eye(m);
    Rm(1, 1)          = -1;   
    Rm(m, m)          = -1; 
    RmRmt             = Rm*Rm';
    Rn                = diag(ones(n-1, 1), 1) + diag(ones(n-1, 1), -1)  - 2*eye(n);
    Rn(1, 1)          = -1;   
    Rn(n, n)          = -1; 
    RnRnt             = Rn*Rn';
    Para_LIMC.rho     = 1e-2;
    Para_LIMC.MaxIter = MaxIter;
    Para_LIMC.epsilon = epsilon;
    
    
%% Parameters for variables
    PSNR_All           = zeros(Num_Images, 6);
    SSIM_All           = zeros(Num_Images, 6);
    CPUTime_All        = zeros(Num_Images, 6);
    Gray_Imgaes_IRLS   = zeros(m*2, n*10);
    Gray_Imgaes_PSSV   = zeros(m*2, n*10);
    Gray_Imgaes_LTVNN  = zeros(m*2, n*10);
    Gray_Imgaes_SPC_TV = zeros(m*2, n*10);
    Gray_Imgaes_SPC_QV = zeros(m*2, n*10);
    Gray_Imgaes_LIMC = zeros(m*2, n*10);
    
    
%% Main 
  % The structure
    for i = 1:Num_Images
        i
        if i <= 10
            Index_Row    = 1:m;
            Index_Column = ( 1 + (i-1)*n ):( i*n );
        else
            Index_Row    = ( m+1 ):( 2*m );
            Index_Column = ( 1 + (i-11)*n ):( (i-10)*n );
        end
      % Load the i-th image
        Name_Pic  = strcat([Name_ImagesFile '\'], Name_Images{i});
        Image_Color = imread(Name_Pic);
        Data_Original = double(Image_Color);
      % Generate the text-masked image
        M_Omega = Data_Original.*Omega;
        
        %%%-----------------------------Different Algorithms-----------------------------%%%
      % IRLS
        tic
        Data_Recovered_IRLS = tIRucLq_m(m, n, Omega, M_Omega, lambda_IRLS, q_IRLS, Para_IRLS);  
        % Compute the CPUTime
        CPUTime_IRLS = toc;
        CPUTime_All(i, 1) = CPUTime_IRLS;
        % Output of IRLS
        Data_Recovered_IRLS = max(Data_Recovered_IRLS, 0);
        Data_Recovered_IRLS = min(Data_Recovered_IRLS, 255);
        Data_Recovered_IRLS = M_Omega + Data_Recovered_IRLS.*Unknown;
        % Image set for IRLS 
        Gray_Imgaes_IRLS(Index_Row, Index_Column) = Data_Recovered_IRLS;
        % PSNR
        PSNR_All(i, 1) = PSNR(Data_Original, Data_Recovered_IRLS, Unknown);
        % SSIM
        SSIM_All(i, 1) = ssim_index(Data_Original, Data_Recovered_IRLS);
        
      % PSSV
        PSNR_SSIM_Best = 0;
        for rank_estimate = 5:20
            tic
            Data_Recovered_PSSV_rank = PSSV(m, n, Omega, M_Omega, rank_estimate, Para_PSSV);
            % Compute the CPUTime
            CPUTime_PSSV = toc;
            CPUTime_All(i, 2) = CPUTime_All(i, 2) + CPUTime_PSSV;
            % Output of PSSV
            Data_Recovered_PSSV_rank = max(Data_Recovered_PSSV_rank, 0);
            Data_Recovered_PSSV_rank = min(Data_Recovered_PSSV_rank, 255);
            Data_Recovered_PSSV_rank = M_Omega + Data_Recovered_PSSV_rank.*Unknown;
            % PSNR-rank
            PSNR_rank = PSNR(Data_Original, Data_Recovered_PSSV_rank, Unknown);
            % SSIM-rank
            SSIM_rank = ssim_index(Data_Original, Data_Recovered_PSSV_rank);
            % PSNR-SSIM-rank
            PSNR_SSIM_rank = PSNR_rank + 30*SSIM_rank;
            if PSNR_SSIM_rank >= PSNR_SSIM_Best
                PSNR_SSIM_Best = PSNR_SSIM_rank;
                PSNR_Best = PSNR_rank;
                SSIM_Best = SSIM_rank;
                Data_Recovered_PSSV = Data_Recovered_PSSV_rank;
            end
        end
        % Image set for PSSV
        Gray_Imgaes_PSSV(Index_Row, Index_Column) = Data_Recovered_PSSV;
        % PSNR
        PSNR_All(i, 2) = PSNR_Best;
        % SSIM
        SSIM_All(i, 2) = SSIM_Best;
        
      % LTVNN
        tic
        Data_Recovered_LTVNN = LTVNN(m, n, Omega, M_Omega, gamma_LTVNN, Para_LTVNN);
        % Compute the CPUTime
        CPUTime_LTVNN = toc;
        CPUTime_All(i, 3) = CPUTime_LTVNN;
        % Output of LTVNN
        Data_Recovered_LTVNN = max(Data_Recovered_LTVNN, 0);
        Data_Recovered_LTVNN = min(Data_Recovered_LTVNN, 255);
        Data_Recovered_LTVNN = M_Omega + Data_Recovered_LTVNN.*Unknown;
        % Image set for LTVNN
        Gray_Imgaes_LTVNN(Index_Row, Index_Column) = Data_Recovered_LTVNN;
        % PSNR
        PSNR_All(i, 3)       = PSNR(Data_Original, Data_Recovered_LTVNN, Unknown);
        % SSIM
        SSIM_All(i, 3)      = ssim_index(Data_Original, Data_Recovered_LTVNN);
        
      % SPC-TV
        tic
        Data_Recovered_SPC_TV = SPC(M_Omega, Omega, TV, rho_TV, K, SNR, nu, maxiter, tol, out_im);
        % Compute the CPUTime
        CPUTime_SPC_TV = toc;
        CPUTime_All(i, 4) = CPUTime_SPC_TV;
        % Output of SPC-TV
        Data_Recovered_SPC_TV = max(Data_Recovered_SPC_TV, 0);
        Data_Recovered_SPC_TV = min(Data_Recovered_SPC_TV, 255);
        Data_Recovered_SPC_TV = M_Omega + Data_Recovered_SPC_TV.*Unknown;
        % Image set for SPC_TV
        Gray_Imgaes_SPC_TV(Index_Row, Index_Column) = Data_Recovered_SPC_TV;
        % PSNR
        PSNR_All(i, 4)        = PSNR(Data_Original, Data_Recovered_SPC_TV, Unknown);
        % SSIM
        SSIM_All(i, 4)        = ssim_index(Data_Original, Data_Recovered_SPC_TV);

      % SPC-V
        tic
        Data_Recovered_SPC_QV = SPC(M_Omega, Omega, QV, rho_QV, K, SNR, nu, maxiter, tol, out_im);
        % Compute the CPUTime
        CPUTime_SPC_QV = toc;
        CPUTime_All(i, 5) = CPUTime_SPC_QV;
        % Output of SPC-TV
        Data_Recovered_SPC_QV = max(Data_Recovered_SPC_QV, 0);
        Data_Recovered_SPC_QV = min(Data_Recovered_SPC_QV, 255);
        Data_Recovered_SPC_QV = M_Omega + Data_Recovered_SPC_QV.*Unknown;
        % Image set for SPC_TV
        Gray_Imgaes_SPC_QV(Index_Row, Index_Column) = Data_Recovered_SPC_QV;
        % PSNR
        PSNR_All(i, 5)        = PSNR(Data_Original, Data_Recovered_SPC_QV, Unknown);
        % SSIM
        SSIM_All(i, 5)        = ssim_index(Data_Original, Data_Recovered_SPC_QV);

      % LIMC
        tic
        Data_Recovered_LIMC = LIMC_Ecnomic(m, n, Omega, M_Omega, lambda_LIMC, RmRmt, RnRnt, Para_LIMC);
        % Compute the CPUTime
        CPUTime_LIMC = toc;
        CPUTime_All(i, 6) = CPUTime_LIMC;
        % Output of LIMC
        Data_Recovered_LIMC = max(Data_Recovered_LIMC, 0);
        Data_Recovered_LIMC = min(Data_Recovered_LIMC, 255);
        Data_Recovered_LIMC = M_Omega + Data_Recovered_LIMC.*Unknown;
        % Image set for LIMC
        Gray_Imgaes_LIMC(Index_Row, Index_Column) = Data_Recovered_LIMC;
        % PSNR
        PSNR_All(i, 6)      = PSNR(Data_Original, Data_Recovered_LIMC, Unknown);
        % SSIM
        SSIM_All(i, 6)      = ssim_index(Data_Original, Data_Recovered_LIMC);
        %%%-----------------------------Different Algorithms-----------------------------%%%
        
    end

    
%% Save the results
    save Table_3
    
    
%% Text results
    disp('The PSNR results are as follows: ' )
    disp( PSNR_All )
    disp('The SSIM results are as follows: ' )
    disp( SSIM_All )
    disp('The CPUTime results are as follows: ' )
    disp( CPUTime_All )
    

%% Remind me and also remove the added path
 % Reminder
   load gong.mat; 
   sound(y, Fs)
 % remove the path
   rmpath(PATH_Functions_MC);
   rmpath(PATH_Functions_SPC);
   
   
    