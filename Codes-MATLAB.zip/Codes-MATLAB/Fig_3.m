%% Initialize the enviroment
    clear all
    close all
    clc
    rng('default')


%% Load the data and toolbox
    Gray_Imgaes = uint8(zeros(256*2, 256*10));
    k = 1;
    for i = 1:2
        iIndex = (256*(i-1) + 1):(256*i);
        for j = 1:10
            jIndex = (256*(j-1) + 1):(256*j);
            % Load the data
            if k < 10
                Name_Pic = ['Images-Gray\0' num2str(k)  '.jpg'];
            else
                Name_Pic = ['Images-Gray\' num2str(k)  '.jpg'];
            end
            Image_Gray_ij = imread(Name_Pic);
            Gray_Imgaes(iIndex, jIndex, :) = Image_Gray_ij;
            k = k + 1;
        end
    end
    
    
%% Save results
    save Fig_3
    
    
%% File address
    File_Address = 'Fig_3\';
    mkdir('Fig_3')  
    
    
%% Results
    imshow(Gray_Imgaes)
  % ------- Maximun window of current fig-type picture -------%
    set(gcf, 'outerposition', get(0, 'screensize'));
  % ------- Maximun window of current fig-type picture -------%
    saveas(gcf, [File_Address 'Gray_Imgaes.jpg'])
    saveas(gcf, [File_Address 'Gray_Imgaes.fig'])
    
    
    
    
    
    
    
    
    